# fabapp
Operational Software for any fablab or makerspace

FabApp is an operational web application that seeks to meet the needs of the UTA FabLab as well as any space like it. This system is expected to work with two other projects Octopuppet and JuiceBox. [This is how they interface together.](https://drive.google.com/open?id=0BzhfhIHqhlx1ekFxRVc0VTBLRHc)

Together this allows for an organization to monitor use of their equipment, provide access control, track training certificates, manage inventory, store completed objects for users, and much much more.  This is a project in progress and will continue to have additional functionality added over time. Currently, we are under development and on V0.90.  Please stay tuned and in touch as this project reaches maturity.
If you have any questions you can reach me at jonathan.le2@uta.edu
