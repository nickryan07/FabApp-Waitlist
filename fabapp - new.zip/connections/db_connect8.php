<?php

    // Connecting to mysql database with Role 8
    $mysqli = new mysqli('localhost', 'Fablabian', 'sbVaBEd3eW9dxmdb', 'fabapp-v0.9') or die(mysql_error());

?>