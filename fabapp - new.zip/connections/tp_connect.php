<?php

// Thermal printer connection settings

$tphost = "ip address";
$tpport = 9100;

?>